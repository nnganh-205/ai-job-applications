---
language:
- en
license: mit
task_categories:
- text-generation
- text2text-generation
tags:
- resume
- job-description
- instruction-tuning
- qlora
- llama
- career
pretty_name: IterateCV Resume Tailoring Dataset
size_categories:
- 100<n<1K
---

# IterateCV Resume Tailoring Dataset

## Dataset Description

An instruction-tuning dataset for fine-tuning LLMs to tailor resumes to job descriptions.
Built for the [IterateCV](https://github.com/abhaykanjoor/IterateCV) project.

Each example contains:
- **instruction**: Task description for the model
- **input**: A master resume in JSON format + a job description
- **output**: A tailored version of the resume optimized for the job description

## Dataset Construction

1. Source resume-JD pairs from [`cnamuangtoun/resume-job-description-fit`](https://huggingface.co/datasets/cnamuangtoun/resume-job-description-fit) (Good Fit + Potential Fit labels only)
2. Parsed raw resume text into structured JSON using GPT-4o mini with a custom Pydantic schema (`MasterResume`)
3. Generated tailored resume outputs using GPT-4o mini with a carefully engineered tailoring prompt
4. Formatted into Alpaca-style instruction-tuning JSONL

## Schema

The resume JSON follows this schema:
```
personal_info: {name, email, phone, location, links}
summary: str
experience: [{title, company, dates, bullet_points}]
projects: [{title, tech_stack, description, bullet_points}]
skills: {languages, frameworks, tools, domain_skills}
education: [{degree, institution, dates}]
awards: [{title, year, issuer, description}]
leadership: [{role, organization, dates}]
```

## Splits

| Split | Examples |
|-------|----------|
| Train | 480 |
| Validation | 60 |
| Test | 60 |

## Usage

```python
from datasets import load_dataset

ds = load_dataset("abhaykanjoor/iteratecv-resume-tailoring")
print(ds["train"][0])
```

## Fine-tuned Model

This dataset was used to fine-tune Llama 3.2-3B using QLoRA.
Model available at: `abhaykanjoor/iteratecv-llama-3.2-3b-lora` (coming soon)

## License

MIT
