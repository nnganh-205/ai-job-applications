---
language:
  - vi
task_categories:
  - text-classification
  - sentence-similarity
pretty_name: ViePAWS
tags:
  - vietnamese
  - paraphrase-identification
  - adversarial
  - vietnamese-nlp
size_categories:
  - 10K<n<100K
---

# ViePAWS

**ViePAWS** is a Vietnamese adversarial benchmark for **paraphrase identification** under high lexical overlap.

The dataset contains **11,062 Vietnamese sentence pairs** designed to test whether models can distinguish semantic differences beyond surface-level similarity.

## Task

Given two Vietnamese sentences, predict whether they are paraphrases:

- `1`: Paraphrase
- `0`: Non-paraphrase

ViePAWS includes three fine-grained semantic perturbation types:

- **Semantic Role**
- **Event Structure**
- **Contextual**

## Dataset Construction

The dataset was constructed from Vietnamese Wikipedia through:

1. Candidate sentence pair collection
2. LLM-based silver annotation
3. Adversarial similarity filtering
4. Human verification

The final dataset is balanced between paraphrase and non-paraphrase examples.

## Citation

If you use ViePAWS, please cite:

```bibtex
@INPROCEEDINGS{11685740,
  author={Nguyen, Sang Quang and Van Nguyen, Kiet and Nguyen, Ngan Luu-Thuy and Le, Duy-Dinh},
  booktitle={2026 International Conference on Multimedia Analysis and Pattern Recognition (MAPR)}, 
  title={ViePAWS: A Vietnamese Adversarial Dataset for Paraphrase Identification under LLM-based Word Scrambling}, 
  year={2026},
  volume={},
  number={},
  pages={43-48},
  keywords={Modeling;Labeling;Conferences;Printing;Accuracy;Tuning;Generative Pre-trained transformer;Poles and zeros;Surfaces;Large language models;Vietnamese NLP;paraphrase identification;adversarial word scrambling},
  doi={10.1109/MAPR72750.2026.11685740}
}
```

## Acknowledgements

This research is funded by the **Vietnam National Foundation for Science and Technology Development (NAFOSTED)** under grant **102.05-2025.108**.
